# %%
import os

import networkx as nx
import numpy as np
import torch
from torch_geometric.data import Batch
import pandas as pd
from matplotlib.colors import ListedColormap
from rdkit import Chem
from rdkit.Chem.Draw import rdMolDraw2D
from rdkit.Chem import rdDepictor
rdDepictor.SetPreferCoordGen(True)
from IPython.display import SVG
import cairosvg
import cv2
import matplotlib.cm as cm
from tqdm import tqdm
import matplotlib.pyplot as plt
from model import GIHP
from dataset import *
from utils import *
from Bio.PDB import PDBParser

class GradWAM():
    def __init__(self, model, module):
        self.model = model
        module.register_forward_hook(self.save_hook)
        self.target_feat = None

    def save_hook(self, md, fin, fout):
        self.target_feat = fout.x   

    def __call__(self, data):
        self.model.eval()

        output = self.model(data).view(-1)
        grad = torch.autograd.grad(output, self.target_feat)[0]
        channel_weight = torch.mean(grad, dim=0, keepdim=True)
        channel_weight = normalize(channel_weight)
        weighted_feat = self.target_feat * channel_weight
        cam = torch.sum(weighted_feat, dim=-1).detach().cpu().numpy()
        cam = normalize(cam)

        return output.detach().cpu().numpy(), cam

def clourMol(mol,highlightAtoms_p=None,highlightAtomColors_p=None,highlightBonds_p=None,highlightBondColors_p=None,sz=[400,400], radii=None):
    d2d = rdMolDraw2D.MolDraw2DSVG(sz[0], sz[1])
    op = d2d.drawOptions()
    op.dotsPerAngstrom = 40
    op.useBWAtomPalette()
    mc = rdMolDraw2D.PrepareMolForDrawing(mol)
    d2d.DrawMolecule(mc, legend='', highlightAtoms=highlightAtoms_p,highlightAtomColors=highlightAtomColors_p, highlightBonds= highlightBonds_p,highlightBondColors=highlightBondColors_p, highlightAtomRadii=radii)
    d2d.FinishDrawing()
    svg = SVG(d2d.GetDrawingText())
    res = cairosvg.svg2png(svg.data, dpi = 600, output_width=2400, output_height=2400)
    nparr = np.frombuffer(res, dtype=np.uint8)
    segment_data = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    return segment_data

def main():
    device = torch.device('cuda:0')
    
    fpath = os.path.join('data', 'filtered_hla')
    test_df = pd.read_csv(os.path.join(fpath, 'raw', 'data.csv'))
    test_set = GNNDataset(fpath)

    model = GIHP(3, 25 + 1, embedding_size=128, filter_num=32, out_dim=1).to(device)
    try:
        load_model_dict(model, 'pretrained_model/epoch-41, loss-0.9047, cindex-0.4827, val_loss-0.2441, test_loss-0.0771.pt')
    except:
        model_dict = torch.load('pretrained_model/epoch-41, loss-0.9047, cindex-0.4827, val_loss-0.2441, test_loss-0.0771.pt')
        for key, val in model_dict.copy().items():
            if 'lin_l' in key:
                new_key = key.replace('lin_l', 'lin_rel')
                model_dict[new_key] = model_dict.pop(key)
            elif 'lin_r' in key:
                new_key = key.replace('lin_r', 'lin_root')
                model_dict[new_key] = model_dict.pop(key)
        model.load_state_dict(model_dict)

    gradcam = GradAAM(model, module=model.protein_encoder.features.transition3)

    sequence_list = list(test_df['target_sequence'].unique())

    progress_bar = tqdm(total=len(sequence_list))

    for idx in range(len(test_set)):
        protein = test_df.iloc[idx]['target_sequence']

        if len(sequence_list) == 0:
            break
        if protein in sequence_list:
            sequence_list.remove(protein)
        else:
            continue

        data = Batch.from_data_list([test_set[idx]])
        data = data.to(device)

        _, residue_att = gradcam(data)


        graph_protein = nx.Graph()

        target = data.target
        target = Batch.from_data_list(target)
        for i, attr in enumerate(target.x):
            graph_protein.add_node(i, attr=residue_att[i])

        for src, tgt, attr in zip(target.edge_index[0], target.edge_index[1], target.edge_attr):
            graph_protein.add_edge(src.item(), tgt.item())
        # 打印 networkx 图形对象的节点和边信息
        print(graph_protein.nodes(data=True))
        print(graph_protein.edges(data=True))
        node_values = residue_att
        node_colors = [plt.cm.Reds(value) for value in node_values]
        #nx
        # # 绘制图形
        # nx.draw(graph_protein, with_labels=True,font_size=5, node_color=node_colors,node_size=60)
        # file_path = "results/"+protein[0:10]+".png"
        #
        # plt.savefig(file_path)
        plt.clf()

        B_factor = residue_att * 100
        # 读取PDB文件
        pdb_file = 'pdb/' + protein + '.pdb'
        parser = PDBParser(QUIET=True)
        structure = parser.get_structure('protein', pdb_file)
        with open(pdb_file, 'r') as f:
            pdb_lines = f.readlines()

        start_residue_num = -1
        atom_to_color = dict()
        residue_in_set = set()
        # 打开一个新的PDB文件用于写入
        for i, line in enumerate(pdb_lines):
            if line.startswith('ATOM'):
                residue_name = line[25:26]
                if residue_name not in residue_in_set:
                    residue_in_set.clear()
                    residue_in_set.add(residue_name)
                    start_residue_num += 1
                if start_residue_num >= len(B_factor):
                    continue
                atom_to_color[i] = B_factor[start_residue_num]

                # print(residue_name)
        with open('colored_' + protein + '.pdb', 'w') as f:
            for i, line in enumerate(pdb_lines):
                # 在ATOM记录行中添加颜色信息到B-factor字段
                if line.startswith('ATOM'):
                    # 将颜色信息转换为B-factor值
                    bfactor_value = atom_to_color[i]  # 使用适当的数据
                    # 格式化B-factor字段，通常限定到6位小数
                    bfactor_field = f'{bfactor_value:.2f}'
                    # 替换B-factor字段
                    line = line[:61] + bfactor_field + line[66:]
                # 写入新的行到新的PDB文件
                f.write(line)


        progress_bar.update(1)

if __name__ == '__main__':
    main()

